const { test, expect } = require('../../fixtures/test-fixtures');

test.describe('Users API', () => {
  test('@smoke @regression debe obtener lista de usuarios', async ({ request, apiConfig }) => {
    const response = await request.get(`${apiConfig.apiUrl}/users`);

    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(Array.isArray(body)).toBeTruthy();
    expect(body.length).toBeGreaterThan(0);
    expect(body[0]).toHaveProperty('id');
    expect(body[0]).toHaveProperty('name');
    expect(body[0]).toHaveProperty('email');
  });

  test('@regression debe obtener un usuario por id', async ({ request, apiConfig }) => {
    const response = await request.get(`${apiConfig.apiUrl}/users/1`);

    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    expect(body.id).toBe(1);
    expect(body).toHaveProperty('username');
  });

  test('@regression debe validar recurso inexistente', async ({ request, apiConfig }) => {
    const response = await request.get(`${apiConfig.apiUrl}/users/99999`);

    expect(response.status()).toBe(404);
  });
});
