const { test, expect } = require('../../fixtures/test-fixtures');
const { LoginPage } = require('../../pages/LoginPage');

test.describe('Login UI', () => {
  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.open();
  });

  test('@smoke @regression debe iniciar sesión correctamente con credenciales válidas', async ({ page, credentials }) => {
    const loginPage = new LoginPage(page);

    await test.step('Ingresar credenciales válidas', async () => {
      await loginPage.login(credentials.valid.username, credentials.valid.password);
    });

    await test.step('Validar acceso exitoso', async () => {
      await expect(page).toHaveURL(/logged-in-successfully/);
      await expect(loginPage.successTitle).toHaveText('Logged In Successfully');
      await expect(loginPage.logoutButton).toBeVisible();
    });
  });

  test('@regression debe mostrar error con usuario inválido', async ({ page, credentials }) => {
    const loginPage = new LoginPage(page);

    await loginPage.login(credentials.invalid.username, credentials.invalid.password);

    await expect(loginPage.errorMessage).toContainText('Your username is invalid!');
  });

  test('@regression debe mostrar error con password incorrecto', async ({ page, credentials }) => {
    const loginPage = new LoginPage(page);

    await loginPage.login(credentials.valid.username, credentials.invalid.password);

    await expect(loginPage.errorMessage).toContainText('Your password is invalid!');
  });
});
