# QA Portfolio Evidence – Playwright

## Stack
- Playwright
- JavaScript
- UI Testing
- API Testing
- Page Object Model
- Fixtures
- Hooks
- Environment variables
- GitHub Actions

## Installation
```bash
npm install
npx playwright install
```

## Setup
1. Copia el archivo `.env.example`
2. Renómbralo a `.env`

## Run tests
### All
```bash
npm test
```

### Smoke
```bash
npm run test:smoke
```

### Regression
```bash
npm run test:regression
```

### UI only
```bash
npm run test:ui
```

### API only
```bash
npm run test:api
```

### Headed mode
```bash
npm run test:headed
```

### Open report
```bash
npm run report
```

## Project structure
```bash
qa-portfolio-evidence/
├── .github/workflows/playwright.yml
├── docs/
│   ├── bug-report-example.md
│   ├── evidence-summary.md
│   ├── test-cases.md
│   └── test-plan.md
├── fixtures/
│   └── test-fixtures.js
├── pages/
│   └── LoginPage.js
├── tests/
│   ├── api/
│   │   └── users.spec.js
│   └── ui/
│       └── login.spec.js
├── utils/
│   └── test-data.js
├── .env.example
├── package.json
└── playwright.config.js
```

## What is covered
### UI
- Successful login
- Invalid username
- Invalid password

### API
- Get all users
- Get user by ID
- Validate 404 for non-existing user




