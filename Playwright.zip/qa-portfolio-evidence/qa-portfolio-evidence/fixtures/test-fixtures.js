const base = require('@playwright/test');
require('dotenv').config();

exports.test = base.test.extend({
  credentials: async ({}, use) => {
    await use({
      valid: {
        username: process.env.VALID_USERNAME || 'student',
        password: process.env.VALID_PASSWORD || 'Password123'
      },
      invalid: {
        username: process.env.INVALID_USERNAME || 'wrongUser',
        password: process.env.INVALID_PASSWORD || 'wrongPass'
      }
    });
  },

  apiConfig: async ({}, use) => {
    await use({
      apiUrl: process.env.API_URL || 'https://jsonplaceholder.typicode.com'
    });
  }
});

exports.expect = base.expect;
