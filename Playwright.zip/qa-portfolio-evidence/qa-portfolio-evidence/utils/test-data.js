const bugExamples = [
  {
    id: 'BUG-001',
    title: 'Mensaje de error visible con usuario inválido',
    expected: 'El sistema debe mostrar mensaje de credenciales inválidas',
    priority: 'Medium'
  }
];

module.exports = { bugExamples };
