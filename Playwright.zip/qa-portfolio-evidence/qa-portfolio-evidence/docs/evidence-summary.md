# Evidence Summary

This repository is designed as portfolio evidence for a Junior QA / QA Automation role.

## What it demonstrates
- Test case design
- Basic test planning
- UI automation with Playwright
- API testing with Playwright request context
- Page Object Model
- Hooks (`beforeEach`)
- Fixtures for reusable test data
- Environment variable usage
- CI pipeline with GitHub Actions
- HTML reports for execution evidence

## Suggested portfolio use
- Upload to GitHub
- Add screenshots of the HTML report
- Mention this project in CV and LinkedIn
- Use it as proof of practical QA knowledge in interviews
