# Bug Report Example

**Bug ID:** BUG-LOGIN-001  
**Title:** Error message is not shown when invalid username is submitted  
**Severity:** Medium  
**Priority:** High  
**Environment:** QA / Chrome / Windows 11  

## Steps to Reproduce
1. Open login page
2. Enter invalid username
3. Enter any password
4. Click submit

## Expected Result
The application should display a visible validation message indicating that the username is invalid.

## Actual Result
The application redirects incorrectly or does not display the expected error.

## Evidence
- Screenshot attached in report
- Automation coverage available in UI suite
