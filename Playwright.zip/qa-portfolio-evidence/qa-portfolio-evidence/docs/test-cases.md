# Test Cases Sample

| ID | Module | Scenario | Preconditions | Steps | Expected Result | Type |
|---|---|---|---|---|---|---|
| TC-001 | Login | Successful login | User on login page | Enter valid username and password, click submit | User is redirected to success page | Positive |
| TC-002 | Login | Invalid username | User on login page | Enter invalid username and valid password, click submit | Error message is displayed | Negative |
| TC-003 | Login | Invalid password | User on login page | Enter valid username and invalid password, click submit | Error message is displayed | Negative |
| TC-004 | API | Get users list | API available | Send GET /users | Status 200 and response contains users | Functional |
| TC-005 | API | Get invalid user | API available | Send GET /users/99999 | Status 404 | Negative |
