# Test Plan – QA Portfolio Evidence

## Project Objective
Validate the login flow and core API endpoints to demonstrate QA analysis, manual validation logic, and automation coverage.

## Scope
### In Scope
- Login UI
- Positive and negative scenarios
- Users API
- Smoke and regression labels
- HTML report evidence

### Out of Scope
- Performance testing
- Security testing
- Mobile app testing

## Test Types
- Smoke
- Functional
- Negative
- API validation

## Entry Criteria
- Environment available
- Test data configured
- Dependencies installed
- Browser installed with Playwright

## Exit Criteria
- Smoke suite completed
- No blockers preventing execution
- Evidence generated in report
